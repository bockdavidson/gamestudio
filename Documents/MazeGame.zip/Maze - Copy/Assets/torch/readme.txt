Simple torch by Axel Vaude. 26 Feb. 2013


How to use:
drag and drop torch.prefab in your 3d scene (in the torch directory).
In the Inspector a script allow you to change the light intensity of the torch.




note that a graphic bug can appear in deferred rendering, the 3d object torch is display before the particle.
You can see it in the scene sample02.


Any problems or suggestions please email me at dsimplex62@hotmail.com



PS: 
Stone textures made by Nobiax on Deviant Art.
http://nobiax.deviantart.com/art/Free-3D-textures-pack-14-243349578